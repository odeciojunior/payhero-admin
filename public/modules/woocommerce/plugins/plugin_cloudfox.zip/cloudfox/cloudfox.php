<?php
/**
 * Plugin Name: Cloudfox Checkout WooCommerce Integration
 * Plugin URI: https://cloudfox.net
 * Description: Integrates transparent checkout for WooCommerce with Cloudfox payment gate.
 * Version: 1.0
 * Author: Cloudfox
 * Author URI: https://cloudfox.net
 */


wp_register_script( 'my_plugin_script', plugins_url('/main.js', __FILE__), array('jquery'));

wp_enqueue_script( 'my_plugin_script' );

//apply_filters( 'woocommerce_webhook_deliver_async', '__return_false' );