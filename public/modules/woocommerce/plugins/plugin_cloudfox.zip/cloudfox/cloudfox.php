<?php
/**
 * Plugin Name: Cloudfox Checkout Integration
 * Plugin URI: 
 * Description: Integrates transparent checkout for your online store with Cloudfox payment gate.
 * Version: 1.0
 * Author: Cloudfox
 * Author URI: https://cloudfox.net
 */


wp_register_script( 'my_plugin_script', plugins_url('/main.js', __FILE__), array('jquery'));

wp_enqueue_script( 'my_plugin_script' );
