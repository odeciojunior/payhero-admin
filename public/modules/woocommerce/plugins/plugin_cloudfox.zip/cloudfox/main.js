jQuery(document).ready(function($){
    //alert('oi')
    
    //checkout button
    function html2json() {
        var json = '{';
        var otArr = [];
        var tbl2 = $('.shop_table tr.woocommerce-cart-form__cart-item').each(function(i) {        
           x = $(this).children();
           var itArr = [];
           x.each(function() {
                if($(this).hasClass('product-remove')){
                    //itArr.push('"' + $('a',this).attr('data-product_id') + '"');
                    itArr.push('"' + $('a',this).attr('data-product_sku') + '"');
                }else if($(this).hasClass('product-quantity')){
                    itArr.push('"' + $('.qty',this).val() + '"');
                    
                }else{
                    //itArr.push('"' + $.trim($(this).text()) + '"');
                }

           });
           //itArr.splice(1,1)
        
           
           otArr.push('"' + i + '": [' + itArr.join(',') + ']');
        })
        json += otArr.join(",") + '}'
        
        return json
        //return json.replace(/(\r\n|\n|\r)/gm, "");
        

    }
    if($('.checkout-button').is(':visible')){
        
        var checkoutUrl = 'https://checkout.';
        var url = $(location).attr('hostname');
        //url = 'belasnovidades.com'
        var urlParts = url.split('.');
        
        if(urlParts[0]=='www'){
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
            if (urlParts.length == 4)
                checkoutUrl += '.' + urlParts[3];
        }else if (urlParts.length == 2){
            checkoutUrl += urlParts[0] + '.' + urlParts[1];
        }else if (urlParts.length == 3){
            checkoutUrl += urlParts[0] + '.' + urlParts[1] + '.' + urlParts[2];
        }else{
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
        }
        //console.log(checkoutUrl);

        //cover when js just dies when tabs are reload in browser
        setInterval(() => {
            $('.checkout-button').click(checkoutButton)
            
        }, 3000);

        $('button[name="apply_coupon"]').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
            },1500)
        })

        $('button[name="update_cart"]').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
            },1500)
        })
        $('.product-remove').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
                $('.restore-item').click(function(){
                    
                    setTimeout(function(){
                        $('.checkout-button').click(checkoutButton)
                    },1500)
                })
            },1500)
        })
        
        

            
        var checkoutButton = function(){

            //var html = '<form id="formt" method="post" action="http://dev.checkout.com/">'
            var html = '<form id="formt" method="post" action="'+checkoutUrl+'">'


        
            var products = html2json()
            var obj = $.parseJSON(products);
            //console.log(obj);
            var i = 0;
            

            for (key in obj) {

            
                var product_id = obj[i][0]
                var ammount = obj[i][1]
                var price = 1
                // price = price.replace('R$','')
                // price = price.replace(',','')
                //console.log(product_id);
                // console.log(url.length,url);
                
                i++

                html += '<input type="hidden" name="product_id_'+i+'" value="'+product_id+'" />'
                html += '<input type="hidden" name="variant_id_'+i+'" value="'+product_id+'" />'
                html += '<input type="hidden" name="product_price_'+i+'" value="'+price+'" />'
                html += '<input type="hidden" name="product_amount_'+i+'" value="'+ammount+'" />'
                html += '<input type="hidden" name="updates[]" value="1" />'

            }
    
            html += '</form>'

            $('.checkout-button').after(html);

            $('#formt').submit()
            //console.log('test');
            return false;
        }
        
        $('.checkout-button').click(checkoutButton)

    }

    
    
});