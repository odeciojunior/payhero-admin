jQuery(document).ready(function($){

    // Parse cart table
    function html2json() {
        var json = '{';
        var otArr = [];
        var tbl2 = $('.shop_table tr.woocommerce-cart-form__cart-item').each(function(i) {        
           x = $(this).children();
           var itArr = [];
           x.each(function() {
                if($(this).hasClass('product-remove')){
                    
                    itArr.push('"' + $('a',this).attr('data-product_sku') + '"');

                }else if($(this).hasClass('product-quantity')){

                    itArr.push('"' + $('.qty',this).val() + '"');
                    
                }

           });
                      
           otArr.push('"' + i + '": [' + itArr.join(',') + ']');
        })
        json += otArr.join(",") + '}'
        
        return json
        
    }

    setInterval(() => {
        if($('.checkout').is(':visible')){
        
            $('.checkout').click(function(){
                
                
                var url = $(this).prev('a').attr('href')
                if(!url){
                    url = $(this).next('a').attr('href')
                }
                window.location = url
                return false
            })
        }
    }, 3000);

    if($('.checkout-button').is(':visible')){
        
        // Prepare checkout Url
        var checkoutUrl = 'https://checkout.';
        var url = $(location).attr('hostname');
        
        var urlParts = url.split('.');
        
        if(urlParts[0]=='www'){
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
            if (urlParts.length == 4)
                checkoutUrl += '.' + urlParts[3];
        }else if (urlParts.length == 2){
            checkoutUrl += urlParts[0] + '.' + urlParts[1];
        }else if (urlParts.length == 3){
            checkoutUrl += urlParts[0] + '.' + urlParts[1] + '.' + urlParts[2];
        }else{
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
        }
        
        // Cover when js just dies when tabs first time load in browser
        setInterval(() => {
            $('.checkout-button').click(checkoutButton)
           
        }, 3000);

        $('button[name="apply_coupon"]').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
            },1500)
        })

        $('button[name="update_cart"]').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
            },1500)
        })

        $('.product-remove').click(function(){
            setTimeout(function(){
                $('.checkout-button').click(checkoutButton)
                $('.restore-item').click(function(){
                    
                    setTimeout(function(){
                        $('.checkout-button').click(checkoutButton)
                    },1500)
                })
            },1500)
        })
        
        

        // Checkout button function
        var checkoutButton = function(){

            // var html = '<form id="formt" method="post" action="http://dev.checkout.com/">'
            var html = '<form id="formt" method="post" action="'+checkoutUrl+'">'
        
            var products = html2json()
            var obj = $.parseJSON(products);
            
            var i = 0;
            

            for (key in obj) {

            
                var product_id = obj[i][0]
                var ammount = obj[i][1]
                var price = 1
                                
                i++

                html += '<input type="hidden" name="product_id_'+i+'" value="'+product_id+'" />'
                html += '<input type="hidden" name="variant_id_'+i+'" value="'+product_id+'" />'
                html += '<input type="hidden" name="product_price_'+i+'" value="'+price+'" />'
                html += '<input type="hidden" name="product_amount_'+i+'" value="'+ammount+'" />'
                html += '<input type="hidden" name="updates[]" value="1" />'

            }
    
            html += '</form>'

            $('.checkout-button').after(html);

            $('#formt').submit()
            
            return false;
        }
        
        // Apply functionality
        $('.checkout-button').click(checkoutButton)

    } 
    
});