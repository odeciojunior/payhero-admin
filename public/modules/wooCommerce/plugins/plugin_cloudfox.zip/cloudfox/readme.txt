=== Plugin Name ===
Contributors: paulophp
Donate link: 
Tags: checkout, cloudfox, online, store
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Cloudfox transparent checkout for wordpress store plugin.

== Description ==

This plugin is the Cloudfox transparent checkout for the wordpress store plugin.
It allows users to use the Cloudfox transparent checkout in their stores.

== Frequently Asked Questions ==

= What is this plugin for? =

It allows users to use the Cloudfox transparent checkout in their stores.

== Screenshots ==

1. logo.png

== Changelog ==


== Upgrade Notice ==


