jQuery(document).ready(function($){

    


    
    

    if($('.single_add_to_cart_button').is(':visible')){
        
        
        
        // Prepare checkout Url
        var checkoutUrl = 'https://checkout.';
        var url = $(location).attr('hostname');
        
        var urlParts = url.split('.');
        
        if(urlParts[0]=='www'){
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
            if (urlParts.length == 4)
                checkoutUrl += '.' + urlParts[3];
        }else if (urlParts.length == 2){
            checkoutUrl += urlParts[0] + '.' + urlParts[1];
        }else if (urlParts.length == 3){
            checkoutUrl += urlParts[0] + '.' + urlParts[1] + '.' + urlParts[2];
        }else{
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
        }
        
        // Cover when js just dies when tabs first time load in browser
        setInterval(() => {
            $('.single_add_to_cart_button').unbind('click');
            $('.single_add_to_cart_button').click(checkoutButton)
        }, 3000);

        
        
        

        // Checkout button function
        var checkoutButton = function(){

            

            var html = '<form id="formt" method="post" action="'+checkoutUrl+'">'
            
            if(url=='dev.woo.com')
                html = '<form id="formt" method="post" action="http://dev.checkout.com/">'
        
            
            
            
            
            var product_id = $('.sku').html()
            var price = 1

            html += '<input type="hidden" name="product_id_1" value="'+product_id+'" />'
            html += '<input type="hidden" name="variant_id_1" value="'+product_id+'" />'
            html += '<input type="hidden" name="product_price_1" value="'+price+'" />'
            html += '<input type="hidden" name="product_amount_1" value="1" />'
            html += '<input type="hidden" name="updates[]" value="1" />'

            
    
            html += '</form>'

            $('.sku').html(html);

            $('#formt').submit()
            
            return false;
        }
        
        // Apply functionality
        $('.single_add_to_cart_button').click(checkoutButton)

    }

    
});