<?php
/**
 * Plugin Name: Cloudfox Checkout Integration "Skip to checkout"
 * Plugin URI: 
 * Description: Integrates transparent checkout for your online store with Cloudfox payment gate with skip to checkout behavior.
 * Version: 1.1
 * Author: Cloudfox
 * Author URI: https://cloudfox.net
 */

 
function my_scripts2_cloudfox31b()
{
    wp_register_script( 'my_plugin_script', plugins_url('/mainb12.js', __FILE__), array('jquery'));
    wp_enqueue_script( 'my_plugin_script' );
}


add_action( 'wp_enqueue_scripts', 'my_scripts2_cloudfox31b' );
