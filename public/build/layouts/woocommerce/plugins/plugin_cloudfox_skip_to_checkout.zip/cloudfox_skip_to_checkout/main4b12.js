jQuery(document).ready(function($){

    


    
    var url_string = window.location.href;
    var url = new URL(url_string);
    var src = url.searchParams.get('src');
    var utm_source = url.searchParams.get('utm_source');
    var utm_medium = url.searchParams.get('utm_medium');
    var utm_campaign = url.searchParams.get('utm_campaign');
    var utm_term = url.searchParams.get('utm_term');
    var utm_content = url.searchParams.get('utm_content');

    if( (src != null) || (utm_source != null) || (utm_medium != null) || (utm_campaign != null) || (utm_term != null) || (utm_content != null) )
    {
        
        var cookieName = '_sirius_track';
        var cookieValue = 'src='+src+'|'+'utm_source='+utm_source+'|'+'utm_medium='+utm_medium+'|'+'utm_campaign='+utm_campaign+'|'+'utm_term='+utm_term+'|'+'utm_content='+utm_content;
        var myDate = new Date();
        myDate.setMonth(myDate.getMonth() + 12);

        document.cookie = cookieName +'=' + cookieValue + ';path=/;expires=' + myDate.toUTCString();
    }

    const getCookieValue = (name) => (
        document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')?.pop() || ''
    )

    extra_params = getCookieValue('_sirius_track')
    
    if(extra_params){
        extra_params = '?' + extra_params.split('|').join('&')
    }

    if($('.single_add_to_cart_button').is(':visible')){
        
        
        
        // Prepare checkout Url
        var checkoutUrl = 'https://checkout.';
        var url = $(location).attr('hostname');
        
        var urlParts = url.split('.');
        
        if(urlParts[0]=='www'){
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
            if (urlParts.length == 4)
                checkoutUrl += '.' + urlParts[3];
        }else if (urlParts.length == 2){
            checkoutUrl += urlParts[0] + '.' + urlParts[1];
        }else if (urlParts.length == 3){
            checkoutUrl += urlParts[0] + '.' + urlParts[1] + '.' + urlParts[2];
        }else{
            checkoutUrl += urlParts[1] + '.' + urlParts[2];
        }
        
        // Cover when js just dies when tabs first time load in browser
        // setInterval(() => {
            // $('.single_add_to_cart_button').unbind('click');
            // $('.single_add_to_cart_button').click(checkoutButton)
        // }, 3000);

        
        
        

        // Checkout button function
        var checkoutButton = function(){

            if($('.single_add_to_cart_button').hasClass('disabled')){
                alert('Selecione uma das opções do produto antes de adicioná-lo ao carrinho.')
                return false
            } 
                

            var html = '<form id="formt" method="post" action="'+checkoutUrl+extra_params+'">'
            
            if(url=='dev.woo.com')
                html = '<form id="formt" method="post" action="http://dev.checkout.com/">'
        
            
            
            
            if($('.variations_form').is(':visible')){
                selectedVariation = $('.variation_id').val()
                var data = JSON.parse($('.variations_form').attr('data-product_variations'));
                for(i in data){
                    if(data[i].variation_id == selectedVariation){
                        var product_id = data[i].sku

                    }
                }
            }else{
                var product_id = $('.sku-value').html()
            }
            var price = 1

            html += '<input type="hidden" name="product_id_1" value="'+product_id+'" />'
            html += '<input type="hidden" name="variant_id_1" value="'+product_id+'" />'
            html += '<input type="hidden" name="product_price_1" value="'+price+'" />'
            html += '<input type="hidden" name="product_amount_1" value="1" />'
            html += '<input type="hidden" name="updates[]" value="1" />'

            
    
            html += '</form>'

            $('.sku-value').html(html);

            $('#formt').submit()
            
            return false;
        }
        
        // Apply functionality
        $('.single_add_to_cart_button').click(checkoutButton)

    }

    
});